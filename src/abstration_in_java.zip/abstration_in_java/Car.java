package abstration_in_java;

public class Car extends Vehicle{
	public void changeGear() {
		System.out.println("Gear Changed");
	}
}
