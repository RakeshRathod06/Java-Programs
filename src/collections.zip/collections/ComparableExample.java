package collections;

public class ComparableExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
