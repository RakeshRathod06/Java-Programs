package collections;

public class StudentComparable {
	int rollNo;
	String name;
	int age;
	public StudentComparable(int rollNo, String name, int age) {
		super();
		this.rollNo = rollNo;
		this.name = name;
		this.age = age;
	}
	
	
	
}
